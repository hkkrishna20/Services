package com.example.demo.service;

import com.example.demo.model.Profile2;

public interface EmailService {
	public void isValid(Profile2 email);
}
