package com.task.taskmanager.models.entity;
public enum Categories {
	Critical,  
	High,  
	Medium,
	Low
}
