package com.cgi.integration.service;
@SuppressWarnings("serial")
public class DetailsNotFoundException extends Exception {
 
    public DetailsNotFoundException(String message) {
        super(message);
    }
}