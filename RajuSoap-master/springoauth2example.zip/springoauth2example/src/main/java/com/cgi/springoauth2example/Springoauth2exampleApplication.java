package com.cgi.springoauth2example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springoauth2exampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springoauth2exampleApplication.class, args);
	}

}
